﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCPartPicker
{
    public partial class CustomerSupport : Form
    {
        public CustomerSupport()
        {
            InitializeComponent();
            pictureBoxSupport.Load("https://cdn.pixabay.com/photo/2019/09/16/22/38/service-4482162__340.jpg");
        }
    }
}
