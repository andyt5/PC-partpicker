namespace PCPartPicker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /*
         * Andy Tang
         * Opens the customer support form
         */
        private void customerSupportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerSupport customerSupport = new CustomerSupport();
            customerSupport.ShowDialog();
        }

        /*
         * Andy Tang
         * Opens the recommended PC parts form
         */
        private void recommendedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Recommended recommended = new Recommended();
            recommended.ShowDialog();
        }

        /*
         * Bryce Becraft
         * Displays and changes the prices for the selected case
         */
        private void comboCase_SelectedIndexChanged(object sender, EventArgs e)
        {

            /*
                Phanteks Enthoo EVOLV TG MicroATX Mini Tower Case
                Fractal Design Meshify C Mini MicroATX Mini Tower Case
                Lian Li Lancool II Mesh ATX Mid Tower Case
                Phanteks Eclipse P500A D-RGB ATX Mid Tower Case
                Corsair 4000D Airflow ATX Mid Tower Case
                Lian Li O11D XL-W ATX Full Tower Case
                Phanteks PH-ES614PC_BK
             */

            //Makes the price visually change based on what's selected in the first box
            switch (comboCase.SelectedIndex)
            {
                case 0:
                    //Phanteks Enthoo EVOLV TG MicroATX Mini Tower Case
                    towerPriceLabel.Text = "$139.99";
                    break;
                case 1:
                    //Fractal Design Meshify C Mini MicroATX Mini Tower Case
                    towerPriceLabel.Text = "$99.99";
                    break;
                case 2:
                    //Lian Li Lancool II Mesh ATX Mid Tower Case
                    towerPriceLabel.Text = "$135.00";
                    break;
                case 3:
                    //Phanteks Eclipse P500A D-RGB ATX Mid Tower Case
                    towerPriceLabel.Text = "$159.99";
                    break;
                case 4:
                    //Corsair 4000D Airflow ATX Mid Tower Case
                    towerPriceLabel.Text = "$104.99";
                    break;
                case 5:
                    //Lian Li O11D XL-W ATX Full Tower Case
                    towerPriceLabel.Text = "$219.99";
                    break;
                case 6:
                    //Phanteks PH-ES614PC_BK
                    towerPriceLabel.Text = "$139.99";
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Makes the hyperlinks work and take you to the PCPartPicker website
         */
        private void towerPriceLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Makes the link change based on what's selected in the first box
            switch (comboCase.SelectedIndex)
            {
                case 0:
                    //Phanteks Enthoo EVOLV TG MicroATX Mini Tower Case
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/8DvZxr/phanteks-enthoo-evolv-tg-gray-atx-mini-tower-case-ph-es314etg_ag") { UseShellExecute = true });
                    break;
                case 1:
                    //Fractal Design Meshify C Mini MicroATX Mini Tower Case
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/JsKcCJ/fractal-design-meshify-c-mini-dark-tg-microatx-mini-tower-case-fd-ca-mesh-c-mini-bko-tgd") { UseShellExecute = true });
                    break;
                case 2:
                    //Lian Li Lancool II Mesh ATX Mid Tower Case
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/d82bt6/lian-li-lancool-ii-mesh-atx-mid-tower-case-lancool-ii-mesh-rgb-black") { UseShellExecute = true });
                    break;
                case 3:
                    //Phanteks Eclipse P500A D-RGB ATX Mid Tower Case
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/LVQfrH/phanteks-eclipse-p500a-d-rgb-atx-mid-tower-case-ph-ec500atg_dbk01") { UseShellExecute = true });
                    break;
                case 4:
                    //Corsair 4000D Airflow ATX Mid Tower Case
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/bCYQzy/corsair-4000d-airflow-atx-mid-tower-case-cc-9011200-ww") { UseShellExecute = true });
                    break;
                case 5:
                    //Lian Li O11D XL-W ATX Full Tower Case
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/3Pn8TW/lian-li-o11d-xl-w-atx-full-tower-case-o11d-xl-w") { UseShellExecute = true });
                    break;
                case 6:
                    //Phanteks PH-ES614PC_BK
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/TXCwrH/phanteks-case-phes614pcbk") { UseShellExecute = true });
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Saves the current build to a text file in the project's directory
         */
        private void btnSave_Click(object sender, EventArgs e)
        {
            String[] pcBuild = new String[8]; //7 names + 7 prices
            decimal[] pcBuildPrice = new decimal[8];
            string filename = AppDomain.CurrentDomain.BaseDirectory + "lastBuild.txt";

            //Makes sure all the boxes have been changed
            if (comboCase.SelectedIndex >= 0 && comboMotherboard.SelectedIndex >= 0 && comboCPU.SelectedIndex >= 0 && comboRAM.SelectedIndex >= 0
                && comboStorage.SelectedIndex >= 0 && comboGPU.SelectedIndex >= 0 && comboPower.SelectedIndex >= 0)
            {
                //Storing the names in to the PC Build array
                pcBuild[0] = comboCase.Text;
                pcBuild[1] = comboMotherboard.Text;
                pcBuild[2] = comboCPU.Text;
                pcBuild[3] = comboRAM.Text;
                pcBuild[4] = comboStorage.Text;
                pcBuild[5] = comboPower.Text;
                pcBuild[6] = comboGPU.Text;
                pcBuildPrice[0] = decimal.Parse(towerPriceLabel.Text, System.Globalization.NumberStyles.Currency);
                pcBuildPrice[1] = decimal.Parse(motherBoardPrice.Text, System.Globalization.NumberStyles.Currency);
                pcBuildPrice[2] = decimal.Parse(cpuPrice.Text, System.Globalization.NumberStyles.Currency);
                pcBuildPrice[3] = decimal.Parse(ramPrice.Text, System.Globalization.NumberStyles.Currency);
                pcBuildPrice[4] = decimal.Parse(storagePrice.Text, System.Globalization.NumberStyles.Currency);
                pcBuildPrice[5] = decimal.Parse(powerPrice.Text, System.Globalization.NumberStyles.Currency);
                pcBuildPrice[6] = decimal.Parse(gpuPrice.Text, System.Globalization.NumberStyles.Currency);
                decimal totalPrice = pcBuildPrice.Sum();
                using (StreamWriter sw = new StreamWriter(filename))
                {
                    for (int i = 0; i < 7; i++)
                    {
                        sw.WriteLine(pcBuild[i] + "\t" + "$"+pcBuildPrice[i]);
                    }
                }
                //Felt redundant
                //MessageBox.Show("Current build successfully saved!", "Build saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("You didn't select all your parts, you left at least one or more of the boxes empty!", "Incomplete build", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Andy Tang
         * Displays and changes the prices for the selected motherboard
         */
        private void comboMotherboard_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
             * MSI B550-A PRO ATX AM4 Motherboard
             * Gigabyte B660M DS3H DDR4 Micro ATX LGA1700 Motherboard
             * MSI MAG B550M MORTAR WIFI Micro ATX AM4 Motherboard
             * Asus ROG STRIX B550-F GAMING (WI-FI)
             * MSI B450 TOMAHAWK MAX
             * Asus ROG STRIX B550-F GAMING ATX AM4 Motherboard
             * Asus PRIME B450M-A/CSM Micro ATX AM4 Motherboard
             */
            switch (comboMotherboard.SelectedIndex)
            {
                case 0:
                    //MSI B550-A PRO ATX AM4 Motherboard
                    motherBoardPrice.Text = "$146.72";
                    break;
                case 1:
                    //Gigabyte B660M DS3H DDR4 Micro ATX LGA1700 Motherboard
                    motherBoardPrice.Text = "$119.99";
                    break;
                case 2:
                    //MSI MAG B550M MORTAR WIFI Micro ATX AM4 Motherboard
                    motherBoardPrice.Text = "$214.00";
                    break;
                case 3:
                    //Asus ROG STRIX B550-F GAMING (WI-FI)
                    motherBoardPrice.Text = "$209.99";
                    break;
                case 4:
                    //MSI B450 TOMAHAWK MAX
                    motherBoardPrice.Text = "$99.99";
                    break;
                case 5:
                    //Asus ROG STRIX B550-F GAMING ATX AM4 Motherboard
                    motherBoardPrice.Text = "$179.99";
                    break;
                case 6:
                    //Asus PRIME B450M-A/CSM Micro ATX AM4 Motherboard
                    motherBoardPrice.Text = "$111.48";
                    break;
            }
        }

        /*
         * Andy Tang
         * Makes the hyperlinks work and take you to the PCPartPicker website
         */
        private void motherBoardPrice_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switch (comboMotherboard.SelectedIndex)
            {
                case 0:
                    //MSI B550-A PRO ATX AM4 Motherboard
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/7gxbt6/msi-b550-a-pro-atx-am4-motherboard-b550-a-pro") { UseShellExecute = true });
                    break;
                case 1:
                    //Gigabyte B660M DS3H DDR4 Micro ATX LGA1700 Motherboard
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/Z6ddnQ/gigabyte-b660m-ds3h-ddr4-micro-atx-lga1700-motherboard-b660m-ds3h-ddr4") { UseShellExecute = true });
                    break;
                case 2:
                    //MSI MAG B550M MORTAR WIFI Micro ATX AM4 Motherboard
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/RhrYcf/msi-mag-b550m-mortar-wifi-micro-atx-am4-motherboard-mag-b550m-mortar-wifi") { UseShellExecute = true });
                    break;
                case 3:
                    //Asus ROG STRIX B550-F GAMING (WI-FI)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/vFhmP6/asus-rog-strix-b550-f-gaming-wi-fi-atx-am4-motherboard-rog-strix-b550-f-gaming-wi-fi") { UseShellExecute = true });
                    break;
                case 4:
                    //MSI B450 TOMAHAWK MAX
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/jcYQzy/msi-b450-tomahawk-max-atx-am4-motherboard-b450-tomahawk-max") { UseShellExecute = true });
                    break;
                case 5:
                    //Asus ROG STRIX B550-F GAMING ATX AM4 Motherboard
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/JXBhP6/asus-rog-strix-b550-f-gaming-atx-am4-motherboard-rog-strix-b550-f-gaming") { UseShellExecute = true });
                    break;
                case 6:
                    //Asus PRIME B450M-A/CSM Micro ATX AM4 Motherboard
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/wW66Mp/asus-prime-b450m-acsm-micro-atx-am4-motherboard-prime-b450m-acsm") { UseShellExecute = true });
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Displays and changes the prices for the selected case
         */
        private void comboCPU_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
             * AMD Ryzen 7 3700X 3.6 GHz 8-Core Processor
             * AMD Ryzen 5 2600 3.4 GHz 6-Core Processor
             * AMD Ryzen 5 5600G 3.9 GHz 6-Core Processor
             * Intel Core i7-3770K 3.5 GHz Quad-Core Processor
             * Intel Core i5-3570K 3.4 GHz Quad-Core Processor
             * Intel Core i5-4670K 3.4 GHz Quad-Core Processor
             * Intel Core i5-4690 3.5 GHz Quad-Core Processor 
             */

            //Makes the price visually change based on what's selected in the first box
            switch (comboCPU.SelectedIndex)
            {
                case 0:
                    //AMD Ryzen 7 3700X 3.6 GHz 8-Core Processor
                    cpuPrice.Text = "$289.99";
                    break;
                case 1:
                    //AMD Ryzen 5 2600 3.4 GHz 6-Core Processor
                    cpuPrice.Text = "$279.99"; 
                    break;
                case 2:
                    //AMD Ryzen 5 5600G 3.9 GHz 6-Core Processor
                    cpuPrice.Text = "$186.99";
                    break;
                case 3:
                    //Intel Core i7-3770K 3.5 GHz Quad-Core Processor
                    cpuPrice.Text = "$275.00"; 
                    break;
                case 4:
                    //Intel Core i5-3570K 3.4 GHz Quad-Core Processor
                    cpuPrice.Text = "$165.89"; 
                    break;
                case 5:
                    //Intel Core i5-4670K 3.4 GHz Quad-Core Processor
                    cpuPrice.Text = "$123.98"; 
                    break;
                case 6:
                    //Intel Core i5-4690 3.5 GHz Quad-Core Processor
                    cpuPrice.Text = "$134.60";
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Loads text file lastBuild in project directory and displays it
         */
        private void btnView_Click(object sender, EventArgs e)
        {
            string filename = AppDomain.CurrentDomain.BaseDirectory + "lastBuild.txt";
            decimal totalPrice = 0;
            if (File.Exists(filename))
            {
                listViewParts.Items.Clear(); //Preventing the build from showing multiple times if the user clicks "view build" more than once

                string line = "";
                StreamReader sr = new StreamReader(filename);

                while ((line = sr.ReadLine()) != null)
                {
                    /*
                     * Andy Tang
                     * Cleans up display to proper alignment
                     */

                    //gets the line written in text file (format: [part name]\t[price]) into array then added items to list view
                    var splitted = line.Split('\t');
                    ListViewItem listViewPCParts = new ListViewItem(splitted[0]);
                    listViewPCParts.SubItems.Add(splitted[1]);
                    listViewParts.Items.Add(listViewPCParts);
                    totalPrice += Decimal.Parse(splitted[1], System.Globalization.NumberStyles.Currency);

                }

                lblPrice.Text = "Total Price: $"+totalPrice.ToString();
                MessageBox.Show("Last build successfully read.", "Last build loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                sr.Close(); //Closes the text file so people can edit it after it's been read
            } else
            {
                MessageBox.Show("Could not find \"lastBuild.txt\" in " + AppDomain.CurrentDomain.BaseDirectory, "File not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*
         * Bryce Becraft
         * Makes the hyperlinks work and take you to the PCPartPicker website
         */
        private void cpuPrice_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switch (comboCPU.SelectedIndex)
            {
                case 0:
                    //AMD Ryzen 7 3700X 3.6 GHz 8-Core Processor
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/QKJtt6/amd-ryzen-7-3700x-36-ghz-8-core-processor-100-100000071box") { UseShellExecute = true });
                    break;
                case 1:
                    //AMD Ryzen 5 2600 3.4 GHz 6-Core Processor
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/jLF48d/amd-ryzen-5-2600-34ghz-6-core-processor-yd2600bbafbox") { UseShellExecute = true });
                    break;
                case 2:
                    //AMD Ryzen 5 5600G 3.9 GHz 6-Core Processor
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/sYmmP6/amd-ryzen-5-5600g-39-ghz-6-core-processor-100-100000252box") { UseShellExecute = true });
                    break;
                case 3:
                    //Intel Core i7-3770K 3.5 GHz Quad-Core Processor
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/7KjG3C/intel-cpu-bx80637i73770k") { UseShellExecute = true });
                    break;
                case 4:
                    //Intel Core i5-3570K 3.4 GHz Quad-Core Processor
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/3LZQzy/intel-cpu-bx80637i53570k") { UseShellExecute = true });
                    break;
                case 5:
                    //Intel Core i5-4670K 3.4 GHz Quad-Core Processor
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/DNrG3C/intel-cpu-bx80646i54670k") { UseShellExecute = true });
                    break;
                case 6:
                    //Intel Core i5-4690 3.5 GHz Quad-Core Processor
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/r8W9TW/intel-cpu-bx80646i54690") { UseShellExecute = true });
                    break;
            }

        }

        /*
         * Bryce Becraft
         * Makes the hyperlinks work and take you to the PCPartPicker website
         */
        private void ramPrice_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            /*
             * G.Skill Ripjaws X Series 8 GB (2 x 4 GB) DDR3-1600
             * G.Skill Ripjaws V 16 GB (2 x 8 GB) DDR4-3600
             * Corsair Vengeance LPX 16 GB (2 x 8 GB) DDR4-3000
             * Kingston HyperX Fury Black 16 GB (2 x 8 GB) DDR3-1866
             * G.Skill Trident Z RGB 32 GB (2 x 16 GB) DDR4-3200
             */
            switch (comboRAM.SelectedIndex)
            {
                case 0:
                    //G.Skill Ripjaws X Series 8 GB (2 x 4 GB) DDR3-1600
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/LzTmP6/gskill-memory-f312800cl9d8gbxl") { UseShellExecute = true });
                    break;
                case 1:
                    //G.Skill Ripjaws V 16 GB (2 x 8 GB) DDR4-3600
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/jBZzK8/gskill-ripjaws-v-16-gb-2-x-8-gb-ddr4-3600-memory-f4-3600c16d-16gvkc") { UseShellExecute = true });
                    break;
                case 2:
                    //Corsair Vengeance LPX 16 GB (2 x 8 GB) DDR4-3000
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/2skwrH/corsair-memory-cmk16gx4m2b3000c15r") { UseShellExecute = true });
                    break;
                case 3:
                    //Kingston HyperX Fury Black 16 GB (2 x 8 GB) DDR3-1866
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/CtV48d/kingston-memory-hx318c10fbk216") { UseShellExecute = true });
                    break;
                case 4:
                    //G.Skill Trident Z RGB 32 GB (2 x 16 GB) DDR4-3200
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/dHjJ7P/gskill-trident-z-rgb-32gb-2-x-16gb-ddr4-3200-memory-f4-3200c16d-32gtzrx") { UseShellExecute = true });
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Displays and changes the prices for the selected case
         */
        private void comboRAM_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboRAM.SelectedIndex)
            {
                case 0:
                    //G.Skill Ripjaws X Series 8 GB (2 x 4 GB) DDR3-1600
                    ramPrice.Text = "$39.99";
                    break;
                case 1:
                    //G.Skill Ripjaws V 16 GB (2 x 8 GB) DDR4-3600
                    ramPrice.Text = "$82.99";
                    break;
                case 2:
                    //Corsair Vengeance LPX 16 GB (2 x 8 GB) DDR4-3000
                    ramPrice.Text = "$101.99";
                    break;
                case 3:
                    //Kingston HyperX Fury Black 16 GB (2 x 8 GB) DDR3-1866
                    ramPrice.Text = "$149.99";
                    break;
                case 4:
                    //G.Skill Trident Z RGB 32 GB (2 x 16 GB) DDR4-3200
                    ramPrice.Text = "$149.99";
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Displays and changes the prices for the selected case
         */
        private void comboStorage_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboStorage.SelectedIndex)
            {
                case 0:
                    //SeaSonic FOCUS Plus Gold 650 W 80+ Gold
                    storagePrice.Text = "$136.96";
                    break;
                case 1:
                    //Corsair RM (2019) 750 W 80+ Gold
                    storagePrice.Text = "$124.99";
                    break;
                case 2:
                    //SeaSonic FOCUS GX 550 W 80+ Gold
                    storagePrice.Text = "$115.99";
                    break;
                case 3:
                    //EVGA G3 550 W 80+ Gold
                    storagePrice.Text = "$69.98";
                    break;
                case 4:
                    //SeaSonic FOCUS Plus Platinum 850 W 80+ Platinum
                    storagePrice.Text = "$169.99";
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Makes the hyperlinks work and take you to the PCPartPicker website
         */
        private void storagePrice_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            /*
             * Western Digital Caviar Blue 1 TB 3.5" 7200RPM (HDD)
             * Seagate Barracuda 2 TB 3.5" 7200RPM (HDD)
             * Seagate Barracuda Compute 2 TB 3.5" 7200RPM (HDD)
             * Samsung 970 Evo Plus 500 GB M.2-2280 (SSD)
             * Samsung 970 Evo 1 TB M.2-2280 (SSD)
             * Sabrent Rocket Q 1 TB M.2-2280 (SSD)
             */

            switch (comboStorage.SelectedIndex)
            {
                case 0:
                    //Western Digital Caviar Blue 1 TB 3.5" 7200RPM (HDD)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/MwW9TW/western-digital-internal-hard-drive-wd10ezex") { UseShellExecute = true });
                    break;
                case 1:
                    //Seagate Barracuda 2 TB 3.5" 7200RPM (HDD)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/CbL7YJ/seagate-barracuda-2tb-35-7200rpm-internal-hard-drive-st2000dm006") { UseShellExecute = true });
                    break;
                case 2:
                    //Seagate Barracuda Compute 2 TB 3.5" 7200RPM (HDD)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/mwrYcf/seagate-barracuda-computer-2-tb-35-7200rpm-internal-hard-drive-st2000dm008") { UseShellExecute = true });
                    break;
                case 3:
                    //Samsung 970 Evo Plus 500 GB M.2-2280 (SSD)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/TwWfrH/samsung-970-evo-plus-500-gb-m2-2280-nvme-solid-state-drive-mz-v7s500bam") { UseShellExecute = true });
                    break;
                case 4:
                    //Samsung 970 Evo 1 TB M.2-2280 (SSD)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/JLdxFT/samsung-970-evo-10tb-m2-2280-solid-state-drive-mz-v7e1t0baw") { UseShellExecute = true });
                    break;
                case 5:
                    //Sabrent Rocket Q 1 TB M.2-2280 (SSD)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/HmmFf7/sabrent-rocket-q-1-tb-m2-2280-nvme-solid-state-drive-sb-rktq-1tb") { UseShellExecute = true });
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Makes the hyperlinks work and take you to the PCPartPicker website
         */
        private void powerPrice_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switch (comboPower.SelectedIndex)
            {
                case 0:
                    //SeaSonic FOCUS Plus Gold 650 W 80+ Gold
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/WrNypg/seasonic-focus-plus-gold-650w-80-gold-certified-fully-modular-atx-power-supply-ssr-650fx") { UseShellExecute = true });
                    break;
                case 1:
                    //Corsair RM (2019) 750 W 80+ Gold
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/6Y66Mp/corsair-rm-2019-750-w-80-gold-certified-fully-modular-atx-power-supply-cp-9020195-na") { UseShellExecute = true });
                    break;
                case 2:
                    //SeaSonic FOCUS GX 550 W 80+ Gold
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/3H2bt6/seasonic-focus-gx-550-w-80-gold-certified-fully-modular-atx-power-supply-focus-gx-550") { UseShellExecute = true });
                    break;
                case 3:
                    //EVGA G3 550 W 80+ Gold
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/sMM323/evga-supernova-g3-550w-80-gold-certified-fully-modular-atx-power-supply-220-g3-0550") { UseShellExecute = true });
                    break;
                case 4:
                    //SeaSonic FOCUS Plus Platinum 850 W 80+ Platinum
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/P638TW/seasonic-focus-plus-platinum-850w-80-platinum-certified-fully-modular-atx-power-supply-ssr-850px") { UseShellExecute = true });
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Displays and changes the prices for the selected case
         */
        private void comboGPU_SelectedIndexChanged(object sender, EventArgs e)
        {

            /*
             * Asus GeForce GTX 1650 SUPER 4 GB TUF GAMING OC Video Card
             * EVGA GeForce RTX 3070 Ti 8 GB FTW3 ULTRA GAMING Video Card
             * Gigabyte GeForce GTX 1660 SUPER 6 GB OC Video Card
             * Gigabyte GeForce GTX 1070 8 GB GAMING Video Card
             * EVGA GeForce RTX 3060 12 GB XC GAMING Video Card
             * MSI Radeon RX 570 8 GB ARMOR OC Video Card
             */
            switch (comboGPU.SelectedIndex)
            {
                case 0:
                    //Asus GeForce GTX 1650 SUPER 4 GB TUF GAMING OC Video Card
                    gpuPrice.Text = "$249.99";
                    break;
                case 1:
                    //EVGA GeForce RTX 3070 Ti 8 GB FTW3 ULTRA GAMING Video Card
                    gpuPrice.Text = "$777.99";
                    break;
                case 2:
                    //Gigabyte GeForce GTX 1660 SUPER 6 GB OC Video Card
                    gpuPrice.Text = "$239.99";
                    break;
                case 3:
                    //Gigabyte GeForce GTX 1070 8 GB GAMING Video Card
                    gpuPrice.Text = "$277.99";
                    break;
                case 4:
                    //EVGA GeForce RTX 3060 12 GB XC GAMING Video Card
                    gpuPrice.Text = "$399.98";
                    break;
                case 5:
                    //MSI Radeon RX 570 8 GB ARMOR OC Video Card
                    gpuPrice.Text = "$549.95";
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Makes the hyperlinks work and take you to the PCPartPicker website
         */
        private void gpuPrice_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switch (comboPower.SelectedIndex)
            {
                case 0:
                    //Asus GeForce GTX 1650 SUPER 4 GB TUF GAMING OC Video Card
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/DNyqqs/asus-geforce-gtx-1650-super-4-gb-tuf-gaming-oc-video-card-tuf-gtx1650s-o4g-gaming") { UseShellExecute = true });
                    break;
                case 1:
                    //EVGA GeForce RTX 3070 Ti 8 GB FTW3 ULTRA GAMING Video Card
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/M2rRsY/evga-geforce-rtx-3070-ti-8-gb-ftw3-ultra-gaming-video-card-08g-p5-3797-kl") { UseShellExecute = true });
                    break;
                case 2:
                    //Gigabyte GeForce GTX 1660 SUPER 6 GB OC Video Card
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/CnpmP6/gigabyte-geforce-gtx-1660-super-6-gb-oc-video-card-gv-n166soc-6gd") { UseShellExecute = true });
                    break;
                case 3:
                    //Gigabyte GeForce GTX 1070 8 GB GAMING Video Card
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/YpH48d/gigabyte-geforce-gtx-1070-8gb-g1-gaming-video-card-gv-n1070g1-gaming-8gd") { UseShellExecute = true });
                    break;
                case 4:
                    //EVGA GeForce RTX 3060 12 GB XC GAMING Video Card
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/LpbTwP/evga-geforce-rtx-3060-12-gb-xc-gaming-video-card-12g-p5-3657-kr") { UseShellExecute = true });
                    break;
                case 5:
                    //MSI Radeon RX 570 8 GB ARMOR OC Video Card
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://pcpartpicker.com/product/3JdFf7/msi-radeon-rx-570-8gb-armor-oc-video-card-rx-570-armor-8g-oc") { UseShellExecute = true });
                    break;
            }
        }

        /*
         * Bryce Becraft
         * Displays and changes the prices for the selected case
         */
        private void comboPower_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboPower.SelectedIndex)
            {
                case 0:
                    //SeaSonic FOCUS Plus Gold 650 W 80+ Gold
                    powerPrice.Text = "$136.96";
                    break;
                case 1:
                    //Corsair RM (2019) 750 W 80+ Gold
                    powerPrice.Text = "$124.99";
                    break;
                case 2:
                    //SeaSonic FOCUS GX 550 W 80+ Gold
                    powerPrice.Text = "	$115.99";
                    break;
                case 3:
                    //EVGA G3 550 W 80+ Gold
                    powerPrice.Text = "$69.98";
                    break;
                case 4:
                    //SeaSonic FOCUS Plus Platinum 850 W 80+ Platinum
                    powerPrice.Text = "$169.99";
                    break;
            }
        }
    }
}