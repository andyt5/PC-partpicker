﻿namespace PCPartPicker
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboCase = new System.Windows.Forms.ComboBox();
            this.comboMotherboard = new System.Windows.Forms.ComboBox();
            this.comboCPU = new System.Windows.Forms.ComboBox();
            this.comboRAM = new System.Windows.Forms.ComboBox();
            this.comboStorage = new System.Windows.Forms.ComboBox();
            this.comboPower = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.towerPriceLabel = new System.Windows.Forms.LinkLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.customerSupportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recommendedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnView = new System.Windows.Forms.Button();
            this.lblPrice = new System.Windows.Forms.Label();
            this.motherBoardPrice = new System.Windows.Forms.LinkLabel();
            this.label8 = new System.Windows.Forms.Label();
            this.comboGPU = new System.Windows.Forms.ComboBox();
            this.cpuPrice = new System.Windows.Forms.LinkLabel();
            this.ramPrice = new System.Windows.Forms.LinkLabel();
            this.storagePrice = new System.Windows.Forms.LinkLabel();
            this.powerPrice = new System.Windows.Forms.LinkLabel();
            this.gpuPrice = new System.Windows.Forms.LinkLabel();
            this.listViewParts = new System.Windows.Forms.ListView();
            this.Part = new System.Windows.Forms.ColumnHeader();
            this.Price = new System.Windows.Forms.ColumnHeader();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tower Case";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Motherboard";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(12, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "CPU";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(12, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Memory (RAM)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(12, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Storage";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(12, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Power Supply";
            // 
            // comboCase
            // 
            this.comboCase.FormattingEnabled = true;
            this.comboCase.Items.AddRange(new object[] {
            "Phanteks Enthoo EVOLV TG MicroATX Mini Tower Case",
            "Design Meshify C Mini MicroATX Mini Tower Case",
            "Li Lancool II Mesh ATX Mid Tower Case",
            "Eclipse P500A D-RGB ATX Mid Tower Case",
            "4000D Airflow ATX Mid Tower Case",
            "Li O11D XL-W ATX Full Tower Case",
            "PH-ES614PC_BK"});
            this.comboCase.Location = new System.Drawing.Point(135, 93);
            this.comboCase.Name = "comboCase";
            this.comboCase.Size = new System.Drawing.Size(420, 23);
            this.comboCase.TabIndex = 6;
            this.comboCase.SelectedIndexChanged += new System.EventHandler(this.comboCase_SelectedIndexChanged);
            // 
            // comboMotherboard
            // 
            this.comboMotherboard.FormattingEnabled = true;
            this.comboMotherboard.Items.AddRange(new object[] {
            "MSI B550-A PRO ATX AM4 Motherboard",
            "Gigabyte B660M DS3H DDR4 Micro ATX LGA1700 Motherboard",
            "MSI MAG B550M MORTAR WIFI Micro ATX AM4 Motherboard",
            "Asus ROG STRIX B550-F GAMING (WI-FI)",
            "MSI B450 TOMAHAWK MAX",
            "Asus ROG STRIX B550-F GAMING ATX AM4 Motherboard",
            "Asus PRIME B450M-A/CSM Micro ATX AM4 Motherboard"});
            this.comboMotherboard.Location = new System.Drawing.Point(135, 128);
            this.comboMotherboard.Name = "comboMotherboard";
            this.comboMotherboard.Size = new System.Drawing.Size(420, 23);
            this.comboMotherboard.TabIndex = 7;
            this.comboMotherboard.SelectedIndexChanged += new System.EventHandler(this.comboMotherboard_SelectedIndexChanged);
            // 
            // comboCPU
            // 
            this.comboCPU.FormattingEnabled = true;
            this.comboCPU.Items.AddRange(new object[] {
            "AMD Ryzen 7 3700X 3.6 GHz 8-Core Processor",
            "AMD Ryzen 5 2600 3.4 GHz 6-Core Processor",
            "AMD Ryzen 5 5600G 3.9 GHz 6-Core Processor",
            "Intel Core i7-3770K 3.5 GHz Quad-Core Processor",
            "Intel Core i5-3570K 3.4 GHz Quad-Core Processor",
            "Intel Core i5-4670K 3.4 GHz Quad-Core Processor",
            "Intel Core i5-4690 3.5 GHz Quad-Core Processor"});
            this.comboCPU.Location = new System.Drawing.Point(135, 163);
            this.comboCPU.Name = "comboCPU";
            this.comboCPU.Size = new System.Drawing.Size(420, 23);
            this.comboCPU.TabIndex = 8;
            this.comboCPU.SelectedIndexChanged += new System.EventHandler(this.comboCPU_SelectedIndexChanged);
            // 
            // comboRAM
            // 
            this.comboRAM.FormattingEnabled = true;
            this.comboRAM.Items.AddRange(new object[] {
            "G.Skill Ripjaws X Series 8 GB (2 x 4 GB) DDR3-1600",
            "G.Skill Ripjaws V 16 GB (2 x 8 GB) DDR4-3600",
            "Corsair Vengeance LPX 16 GB (2 x 8 GB) DDR4-3000",
            "Kingston HyperX Fury Black 16 GB (2 x 8 GB) DDR3-1866",
            "G.Skill Trident Z RGB 32 GB (2 x 16 GB) DDR4-3200"});
            this.comboRAM.Location = new System.Drawing.Point(135, 198);
            this.comboRAM.Name = "comboRAM";
            this.comboRAM.Size = new System.Drawing.Size(420, 23);
            this.comboRAM.TabIndex = 9;
            this.comboRAM.SelectedIndexChanged += new System.EventHandler(this.comboRAM_SelectedIndexChanged);
            // 
            // comboStorage
            // 
            this.comboStorage.FormattingEnabled = true;
            this.comboStorage.Items.AddRange(new object[] {
            "Western Digital Caviar Blue 1 TB 3.5\" 7200RPM (HDD)",
            "Seagate Barracuda 2 TB 3.5\" 7200RPM (HDD)",
            "Seagate Barracuda Compute 2 TB 3.5\" 7200RPM (HDD)",
            "Samsung 970 Evo Plus 500 GB M.2-2280 (SSD)",
            "Samsung 970 Evo 1 TB M.2-2280 (SSD)",
            "Sabrent Rocket Q 1 TB M.2-2280 (SSD)"});
            this.comboStorage.Location = new System.Drawing.Point(135, 233);
            this.comboStorage.Name = "comboStorage";
            this.comboStorage.Size = new System.Drawing.Size(420, 23);
            this.comboStorage.TabIndex = 10;
            this.comboStorage.SelectedIndexChanged += new System.EventHandler(this.comboStorage_SelectedIndexChanged);
            // 
            // comboPower
            // 
            this.comboPower.FormattingEnabled = true;
            this.comboPower.Items.AddRange(new object[] {
            "EVGA G3 550 W 80+ Gold",
            "SeaSonic FOCUS GX 550 W 80+ Gold",
            "SeaSonic FOCUS Plus Gold 650 W 80+ Gold",
            "Corsair RM (2019) 750 W 80+ Gold",
            "SeaSonic FOCUS Plus Platinum 850 W 80+ Platinum"});
            this.comboPower.Location = new System.Drawing.Point(135, 268);
            this.comboPower.Name = "comboPower";
            this.comboPower.Size = new System.Drawing.Size(420, 23);
            this.comboPower.TabIndex = 11;
            this.comboPower.SelectedIndexChanged += new System.EventHandler(this.comboPower_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(12, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 28);
            this.label7.TabIndex = 12;
            this.label7.Text = "PC Part Picker";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(159, 353);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // towerPriceLabel
            // 
            this.towerPriceLabel.AutoSize = true;
            this.towerPriceLabel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.towerPriceLabel.Location = new System.Drawing.Point(585, 96);
            this.towerPriceLabel.Name = "towerPriceLabel";
            this.towerPriceLabel.Size = new System.Drawing.Size(44, 20);
            this.towerPriceLabel.TabIndex = 14;
            this.towerPriceLabel.TabStop = true;
            this.towerPriceLabel.Text = "$0.00";
            this.towerPriceLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.towerPriceLabel_LinkClicked);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerSupportToolStripMenuItem,
            this.recommendedToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(922, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // customerSupportToolStripMenuItem
            // 
            this.customerSupportToolStripMenuItem.Name = "customerSupportToolStripMenuItem";
            this.customerSupportToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.customerSupportToolStripMenuItem.Text = "Customer Support";
            this.customerSupportToolStripMenuItem.Click += new System.EventHandler(this.customerSupportToolStripMenuItem_Click);
            // 
            // recommendedToolStripMenuItem
            // 
            this.recommendedToolStripMenuItem.Name = "recommendedToolStripMenuItem";
            this.recommendedToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.recommendedToolStripMenuItem.Text = "Recommended";
            this.recommendedToolStripMenuItem.Click += new System.EventHandler(this.recommendedToolStripMenuItem_Click);
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(367, 343);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(92, 43);
            this.btnView.TabIndex = 17;
            this.btnView.Text = "View Last Saved Build";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(795, 325);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(73, 15);
            this.lblPrice.TabIndex = 19;
            this.lblPrice.Text = "Total Price: $";
            // 
            // motherBoardPrice
            // 
            this.motherBoardPrice.AutoSize = true;
            this.motherBoardPrice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.motherBoardPrice.Location = new System.Drawing.Point(585, 131);
            this.motherBoardPrice.Name = "motherBoardPrice";
            this.motherBoardPrice.Size = new System.Drawing.Size(44, 20);
            this.motherBoardPrice.TabIndex = 20;
            this.motherBoardPrice.TabStop = true;
            this.motherBoardPrice.Text = "$0.00";
            this.motherBoardPrice.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.motherBoardPrice_LinkClicked);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(12, 303);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "GPU";
            // 
            // comboGPU
            // 
            this.comboGPU.FormattingEnabled = true;
            this.comboGPU.Items.AddRange(new object[] {
            "Asus GeForce GTX 1650 SUPER 4 GB TUF GAMING OC Video Card",
            "EVGA GeForce RTX 3070 Ti 8 GB FTW3 ULTRA GAMING Video Card",
            "Gigabyte GeForce GTX 1660 SUPER 6 GB OC Video Card",
            "Gigabyte GeForce GTX 1070 8 GB GAMING Video Card",
            "EVGA GeForce RTX 3060 12 GB XC GAMING Video Card",
            "MSI Radeon RX 570 8 GB ARMOR OC Video Card"});
            this.comboGPU.Location = new System.Drawing.Point(135, 303);
            this.comboGPU.Name = "comboGPU";
            this.comboGPU.Size = new System.Drawing.Size(420, 23);
            this.comboGPU.TabIndex = 22;
            this.comboGPU.SelectedIndexChanged += new System.EventHandler(this.comboGPU_SelectedIndexChanged);
            // 
            // cpuPrice
            // 
            this.cpuPrice.AutoSize = true;
            this.cpuPrice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cpuPrice.Location = new System.Drawing.Point(585, 166);
            this.cpuPrice.Name = "cpuPrice";
            this.cpuPrice.Size = new System.Drawing.Size(44, 20);
            this.cpuPrice.TabIndex = 23;
            this.cpuPrice.TabStop = true;
            this.cpuPrice.Text = "$0.00";
            this.cpuPrice.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.cpuPrice_LinkClicked);
            // 
            // ramPrice
            // 
            this.ramPrice.AutoSize = true;
            this.ramPrice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ramPrice.Location = new System.Drawing.Point(585, 201);
            this.ramPrice.Name = "ramPrice";
            this.ramPrice.Size = new System.Drawing.Size(44, 20);
            this.ramPrice.TabIndex = 24;
            this.ramPrice.TabStop = true;
            this.ramPrice.Text = "$0.00";
            this.ramPrice.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ramPrice_LinkClicked);
            // 
            // storagePrice
            // 
            this.storagePrice.AutoSize = true;
            this.storagePrice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.storagePrice.Location = new System.Drawing.Point(585, 233);
            this.storagePrice.Name = "storagePrice";
            this.storagePrice.Size = new System.Drawing.Size(44, 20);
            this.storagePrice.TabIndex = 25;
            this.storagePrice.TabStop = true;
            this.storagePrice.Text = "$0.00";
            this.storagePrice.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.storagePrice_LinkClicked);
            // 
            // powerPrice
            // 
            this.powerPrice.AutoSize = true;
            this.powerPrice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.powerPrice.Location = new System.Drawing.Point(585, 267);
            this.powerPrice.Name = "powerPrice";
            this.powerPrice.Size = new System.Drawing.Size(44, 20);
            this.powerPrice.TabIndex = 26;
            this.powerPrice.TabStop = true;
            this.powerPrice.Text = "$0.00";
            this.powerPrice.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.powerPrice_LinkClicked);
            // 
            // gpuPrice
            // 
            this.gpuPrice.AutoSize = true;
            this.gpuPrice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.gpuPrice.Location = new System.Drawing.Point(585, 302);
            this.gpuPrice.Name = "gpuPrice";
            this.gpuPrice.Size = new System.Drawing.Size(44, 20);
            this.gpuPrice.TabIndex = 27;
            this.gpuPrice.TabStop = true;
            this.gpuPrice.Text = "$0.00";
            this.gpuPrice.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.gpuPrice_LinkClicked);
            // 
            // listViewParts
            // 
            this.listViewParts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Part,
            this.Price});
            this.listViewParts.Location = new System.Drawing.Point(465, 343);
            this.listViewParts.Name = "listViewParts";
            this.listViewParts.Size = new System.Drawing.Size(445, 192);
            this.listViewParts.TabIndex = 28;
            this.listViewParts.UseCompatibleStateImageBehavior = false;
            this.listViewParts.View = System.Windows.Forms.View.Details;
            // 
            // Part
            // 
            this.Part.Text = "Part";
            this.Part.Width = 385;
            // 
            // Price
            // 
            this.Price.Text = "Price";
            this.Price.Width = 55;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 547);
            this.Controls.Add(this.listViewParts);
            this.Controls.Add(this.gpuPrice);
            this.Controls.Add(this.powerPrice);
            this.Controls.Add(this.storagePrice);
            this.Controls.Add(this.ramPrice);
            this.Controls.Add(this.cpuPrice);
            this.Controls.Add(this.comboGPU);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.motherBoardPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.towerPriceLabel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboPower);
            this.Controls.Add(this.comboStorage);
            this.Controls.Add(this.comboRAM);
            this.Controls.Add(this.comboCPU);
            this.Controls.Add(this.comboMotherboard);
            this.Controls.Add(this.comboCase);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "PC Part Picker";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private ComboBox comboCase;
        private ComboBox comboMotherboard;
        private ComboBox comboCPU;
        private ComboBox comboRAM;
        private ComboBox comboStorage;
        private ComboBox comboPower;
        private Label label7;
        private Button btnSave;
        private LinkLabel towerPriceLabel;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem customerSupportToolStripMenuItem;
        private ToolStripMenuItem recommendedToolStripMenuItem;
        private Button btnView;
        private Label lblPrice;
        private LinkLabel motherBoardPrice;
        private Label label8;
        private ComboBox comboGPU;
        private LinkLabel cpuPrice;
        private LinkLabel ramPrice;
        private LinkLabel storagePrice;
        private LinkLabel powerPrice;
        private LinkLabel gpuPrice;
        private ListView listViewParts;
        private ColumnHeader Part;
        private ColumnHeader Price;
    }
}