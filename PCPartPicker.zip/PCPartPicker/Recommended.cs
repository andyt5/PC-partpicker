﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCPartPicker
{
    public partial class Recommended : Form
    {
        public Recommended()
        {
            InitializeComponent();
            pictureBoxRecommended.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxRecommended.Load("https://cdna.pcpartpicker.com/static/forever/images/userbuild/382744.c21abc856cee022c85d70f8f81850fcb.1600.jpg");
            pictureBoxRecommended.SizeMode = PictureBoxSizeMode.StretchImage;
        }
    }
}
